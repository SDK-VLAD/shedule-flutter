class UserProfile {
  static String userFirstName = "";
  static String userLastName = "";
  static String userEmail = "";
  static String userSpeciality = "";
  static String userGroup = "";
}
