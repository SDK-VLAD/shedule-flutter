class Timetable {
  final String id;
  final String weekday;
  final String discipline;
  final String teacher;
  

  const Timetable({
    required this.id,
    required this.weekday,
    required this.teacher,
    required this.discipline
  });

  factory Timetable.fromJson(Map<String, dynamic> json) => Timetable(
        id: json['id'],
        weekday: json['weekday'],
        teacher: json['teacher'],
        discipline: json['discipline'],
      );

  Map<String, dynamic> toJson() => {
    'id': id,
    'discipline': discipline,
    'teacher' : teacher,
      };
}
