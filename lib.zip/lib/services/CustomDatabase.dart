import 'dart:html';

import 'package:flutter/material.dart';

class CustomData extends StatefulWidget {
  @override
  _CustomDataState createState() => _CustomDataState();
}

class _CustomDataState extends State<CustomData> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
