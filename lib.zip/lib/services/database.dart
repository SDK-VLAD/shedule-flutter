import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DatabaseMethods {
  getAllSudents() async {
    return FirebaseFirestore.instance
        .collection("students")
        .orderBy("rank")
        .get()
        .catchError((e) {
      print(e.toString());
    });
  }

  getAllTeachers() async {
    return FirebaseFirestore.instance
        .collection("teachers")
        .orderBy("rank")
        .get()
        .catchError((e) {
      print(e.toString());
    });
  }

  getStudentProfile(String lastName) async {
    return FirebaseFirestore.instance
        .collection("students")
        .where("lastName", isEqualTo: lastName)
        .get()
        .catchError((e) {
      print(e.toString());
    });
  }

  getTeacherProfile(String lastName) async {
    return FirebaseFirestore.instance
        .collection("teachers")
        .where("lastName", isEqualTo: lastName)
        .get()
        .catchError((e) {
      print(e.toString());
    });
  }

  getUserProfile(String email) async {
    return FirebaseFirestore.instance
        .collection("users")
        .where("email", isEqualTo: email)
        .get()
        .catchError((e) {
      print(e.toString());
    });
  }
}

class HelperFunctions {
  static String sharedPreferenceUserKey = "ISLOGGEDIN";
  static String sharedPreferenceUserNameKey = "USERNAMEKEY";
  static String sharedPreferenceUserEmailKey = "USEREMAILKEY";

  static Future<bool> saveUserLoggedInPreference(bool userLoggedIn) async {
    //void
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setBool(sharedPreferenceUserKey, userLoggedIn);
  }

  static Future<bool> saveUserNamePreference(String userName) async {
    //void
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(sharedPreferenceUserNameKey, userName);
  }

  static Future<bool> saveUserEmailPreference(String userEmail) async {
    //void
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(sharedPreferenceUserEmailKey, userEmail);
  }

  static Future<bool?> getUserLoggedInPreference() async {
    //bool
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool(sharedPreferenceUserKey);
  }

  static Future<String?> getUserNamePreference() async {
    //string
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(sharedPreferenceUserNameKey);
  }

  static Future<String?> getUserEmailPreference() async {
    //void
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(sharedPreferenceUserEmailKey);
  }
}
