import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';
import 'package:untitled/screens/screens_bottom/teachers.dart';

import 'package:untitled/services/auth_service.dart';

import '../../constants/constants.dart';
import '../screens_bottom/studentsscreen.dart';

class SaturdayScreen extends StatefulWidget {
  const SaturdayScreen({Key? key}) : super(key: key);
  @override
  SaturdayScreenState createState() => SaturdayScreenState();
}

class SaturdayScreenState extends State<SaturdayScreen> {
  //String _teacherName;
  List saturdaysubjectList = [];
  late String saturdaysubjectElement;

  void initFirebase() async {
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp();
  }

  @override
  void initState() {
    super.initState();
    // TODO: implement initState

    saturdaysubjectList.addAll([
    ]);
  }

//class Home extends StatelessWidget {
  //final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondary,
      appBar: AppBar(
        foregroundColor: textcolor,
        title: const Text(
          'Суббота',
          style: TextStyle(color: textcolor),
        ),
        backgroundColor: primary,
        elevation: 0.0,
        actions: <Widget>[],
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('Saturday').snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return Text('Нет предметов');
          return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (BuildContext context, int index) {
                return Dismissible(
                    key: Key(snapshot.data!.docs[index].id),
                    child: Card(
                      child: ListTile(
                        title: Text(snapshot.data!.docs[index].get('subject')),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: () {
                                FirebaseFirestore.instance
                                    .collection('Saturday')
                                    .doc(snapshot.data!.docs[index].id)
                                    .delete();
                              },
                              icon: Icon(Icons.remove),
                            )
                          ],
                        ),
                      ),
                    ),
                    onDismissed: (direction) {
                      FirebaseFirestore.instance
                          .collection('Saturday')
                          .doc(snapshot.data!.docs[index].id)
                          .delete();
                    });
              });
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.deepOrange,
        onPressed: () {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('Добавить предмет'),
                  content: TextField(
                    onChanged: (String value) {
                      saturdaysubjectElement = value;
                    },
                  ),
                  actions: [
                    ElevatedButton(
                        onPressed: () {
                          FirebaseFirestore.instance
                              .collection('Saturday')
                              .add({'subject': saturdaysubjectElement});
                        },
                        child: Text('Добавить'))
                  ],
                );
              });
        },
        child: const Icon(Icons.create),
      ),

      /*ListView.builder(
            itemCount: subjectList.length,
            itemBuilder: (BuildContext context, int index) {



              return Dismissible(
                  key: Key(subjectList[index]),
                  child: Card(
                    child: ListTile(
                      title: Text(subjectList[index]),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [],
                      ),
                    ),
                  ),
                  onDismissed: (direction) {

                  });
            }),*/

      //shedulerow(),
    );
  }
}
