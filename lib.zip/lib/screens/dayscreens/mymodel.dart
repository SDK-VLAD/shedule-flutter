//import 'dart:convert';

import 'dart:convert';

class Shedulesubjects{
  final int id, subgroup,lessonorder, number, weekday, week ;
  final String discipline, teacher, classroom;

  const Shedulesubjects({
  required this.id,
  required this.subgroup,
  required this.lessonorder,
  required this.number,
  required this.weekday,
  required this.week,
  required this.discipline,
  required this.teacher,
  required this.classroom});

static Shedulesubjects fromJson(json) =>  Shedulesubjects( 
  classroom: json['classroom'], 
  discipline: json['discipline'], 
  lessonorder: json['lessonorder'], 
  number: json['number'], 
  subgroup: json['subgroup'], 
  teacher: json['teacher'], 
  week: json['week'], 
  weekday: json['weekday'], 
  id: json['id'],
  );
}