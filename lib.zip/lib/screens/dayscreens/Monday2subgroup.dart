import 'package:flutter/material.dart';
import 'package:untitled/databases/shedule_api.dart';
import 'package:untitled/screens/dayscreens/Monday1subgroup.dart';
import 'package:untitled/screens/screens_bottom/subjects.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../constants/constants.dart';
import '../home/home.dart';


class MondayScreen2 extends StatefulWidget {
  const MondayScreen2({Key? key}) : super(key: key);
  @override
  MondayScreenState createState() => MondayScreenState();
}


class MondayScreenState extends State<MondayScreen2> {
late Future<List<Timetables>> timetables;

  @override
void initState() {
  super.initState();
  timetables = getTimetablesMonday2();
}

void TimetableTime ()
{
}

  @override
  Widget build(BuildContext context) 
  {
dynamic a = "8:15 - 9:45";
dynamic b = "9:55 - 11:25";
dynamic c = "11:35 - 13:05";
dynamic d = "14:00 - 15:30";

void Monday() {
}


String day_check = '1'; 


        

    return MaterialApp(
      home: Scaffold(appBar: AppBar(
          automaticallyImplyLeading: false,
          foregroundColor: textcolor,
          actions: <Widget>[
          ],
          title: Row(children: <Widget>[
             IconButton(
          icon: Icon(Icons.arrow_back_sharp),
          onPressed: () { Navigator.push( context, MaterialPageRoute( builder: (context) => Home()));
          },
            ),
              Text('Понедельник', style: TextStyle(color: textcolor),),
          ],
          )
          ),
body: Center(
          child: FutureBuilder<List<Timetables>>(
            future: timetables,
            builder: (context, snapshot) {

              if (snapshot.hasData) {
                
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {

                return Column(children: [
                  
                  Text(snapshot.data![index].discipline, style: (const TextStyle(fontWeight: FontWeight.w400, fontSize: 16) ), textAlign: TextAlign.center, ), 
                  Text(snapshot.data![index].lessonOrder, style: (const TextStyle(fontWeight: FontWeight.w800, fontSize: 16) ), textAlign: TextAlign.left, ), 
                  Text(snapshot.data![index].teacher),
                  Text(snapshot.data![index].week, style: (const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, ) ), textAlign: TextAlign.center, ), 
                  Text(snapshot.data![index].weekday, style: (const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, ) ), textAlign: TextAlign.center, ), 
                  Text( snapshot.data![index].classroom, style: (const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, ) ), textAlign: TextAlign.center, ), 
                  const Divider( height: 20, thickness: 3, indent: 0, endIndent: 0, color: Colors.black),],
                  
                  );

              });
              } 
              else if (snapshot.hasError) {
                return Text(snapshot.error.toString());
              } else {
            return CircularProgressIndicator();
              }
          }),
        ),
        bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    TextButton(
                      child: Text('1 Подгруппа'),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                        builder: (context) => MondayScreen()));
                      }, style: TextButton.styleFrom(
        primary: Colors.black,
      ),
                      
                    ),
                    TextButton(
                      child: Text('2 Подгруппа',),
                      onPressed: () {
                        null;
                      },
                      style: TextButton.styleFrom(
        primary: Colors.blue,)
                      )
                   
                    
                  ],
                )))
      ),
    );
  }
  
}            