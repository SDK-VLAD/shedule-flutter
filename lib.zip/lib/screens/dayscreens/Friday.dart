import 'package:flutter/material.dart';
import '../../constants/constants.dart';
import 'mymodel.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class FridayScreen extends StatefulWidget {
  const FridayScreen({Key? key}) : super(key: key);
  @override
  FridayScreenState createState() => FridayScreenState();
}
class FridayScreenState extends State<FridayScreen> {




  @override


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondary,
      appBar: AppBar(
        foregroundColor: textcolor,
        title: const Text(
          'Расписание',
          style: TextStyle(color: textcolor),
        ),
        backgroundColor: primary,
        elevation: 0.0,
        actions: <Widget>[],
      ),
      body: 
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Hello world')
        ],
      )
      );

      

      
    
  }
}
