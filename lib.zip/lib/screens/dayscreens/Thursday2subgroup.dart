import 'package:flutter/material.dart';
import 'package:untitled/databases/shedule_api.dart';


import 'package:untitled/screens/home/home.dart';
import '../../constants/constants.dart';
import 'Thursday1subgroup.dart';
import 'Tuesday2subgroup.dart';


class Thursday2Screen extends StatefulWidget {
  const Thursday2Screen({Key? key}) : super(key: key);
  @override
  Thursday2ScreenState createState() => Thursday2ScreenState();
}


class Thursday2ScreenState extends State<Thursday2Screen> {
late Future<List<Timetables>> timetables;

  @override
void initState() {
  super.initState();
  timetables = getTimetablesThursday1();
}



  @override
  Widget build(BuildContext context) 
  {


    return MaterialApp(
      home: Scaffold(appBar: AppBar(
          automaticallyImplyLeading: false,
          foregroundColor: textcolor,
          actions: <Widget>[],
          title: Row(children: <Widget>[
             IconButton(
          icon: const Icon(Icons.arrow_back_sharp),
          onPressed: () { Navigator.push( context, MaterialPageRoute( builder: (context) => const Home())
          
          );
          },
            ),
              const Text('Четверг', style: TextStyle(color: textcolor),),
          ],
          )
          ),
body: Center(
          child: FutureBuilder<List<Timetables>>(
            future: timetables,
            builder: (context, snapshot) {

              if (snapshot.hasData) {
                
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {

                return Column(children: [
                  
                  Text(snapshot.data![index].discipline, style: (const TextStyle(fontWeight: FontWeight.w400, fontSize: 16) ), textAlign: TextAlign.center, ), 
                  Text(snapshot.data![index].lessonOrder, style: (const TextStyle(fontWeight: FontWeight.w800, fontSize: 16) ), textAlign: TextAlign.left, ), 
                  Text(snapshot.data![index].teacher),
                  Text(snapshot.data![index].week, style: (const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, ) ), textAlign: TextAlign.center, ), 
                  Text(snapshot.data![index].weekday, style: (const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, ) ), textAlign: TextAlign.center, ), 
                  Text( snapshot.data![index].classroom, style: (const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, ) ), textAlign: TextAlign.center, ), 
                  const Divider( height: 20, thickness: 3, indent: 0, endIndent: 0, color: Colors.black),],
                  
                  );
              });
              } 
              else if (snapshot.hasError) {
                return Text(snapshot.error.toString());
              } else {
            return CircularProgressIndicator();
              }
          }),
        ),
        bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    TextButton(
                      child: Text('1 Подгруппа'),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                        builder: (context) => const Thursday1Screen()));
                      }, style: TextButton.styleFrom(
        primary: Colors.black,
      ),
                    ),
                    TextButton(
                      child: Text('2 Подгруппа',),
                      onPressed: () {
                       null;
                      },
                      style: TextButton.styleFrom(
        primary: Colors.blue,)
                      )
                  ],
                )))
      ),
    );
  }
  
}            