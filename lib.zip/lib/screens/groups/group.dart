import 'package:flutter/material.dart';
import 'package:untitled/screens/dayscreens/Friday.dart';
import 'package:untitled/screens/dayscreens/Sunday.dart';
import 'package:untitled/screens/dayscreens/Thursday1subgroup.dart';
import 'package:untitled/screens/dayscreens/Wednesday1subgroup.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';
import 'package:untitled/screens/screens_bottom/teachers.dart';

import 'package:untitled/services/auth_service.dart';

import '../../constants/constants.dart';
import '../screens_bottom/studentsscreen.dart';



class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  HomeState createState() => HomeState();
}

class HomeState extends State<Home> {
  //String _teacherName;
  List dayList = [];
  late String dayElement;

  @override
  void initState() {
    // TODO: implement initState

    dayList.addAll([
      'Понедельник',
      'Вторник',
      'Среда',
      'Четверг',
      'Пятница',
      'Суббота',
      'Воскресенье'
    ]);
  }

//class Home extends StatelessWidget {
  //final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: secondary,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          foregroundColor: textcolor,
          title: const Text(
            'Расписание',
            style: TextStyle(color: textcolor),
          ),
          backgroundColor: primary,
          elevation: 0.0,
          actions: <Widget>[],
        ),
        body: Card(
          child: Column(children: <Widget>[
           
            
            TextButton(
              child: Text('Среда'),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Wednesday1Screen()));
              },
            ),
            TextButton(
              child: Text('Четверг'),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Thursday1Screen()));
              },
            ),
            TextButton(
              child: Text('Пятница'),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => FridayScreen()));
              },
            ),

            
            
            TextButton(
              child: Text('Воскресенье'),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SundayScreen()));
              },
            ),
          ]),
        )

        /*ListView.builder(
            itemCount: dayList.length,
            itemBuilder: (BuildContext context, int index) {
              if (dayList[index] == 'Понедельник') {
                return 

              };
              return Dismissible(
                  key: Key(dayList[index]),
                  child: Card(
                    child: ListTile(
                      title: Text(dayList[index]),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [],
                      ),
                    ),
                  ),
                  onDismissed: (direction) {
                    setState(() {
                      dayList.removeAt(index);
                    });
                  });
            })*/
        ,

        //shedulerow(),
        bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    IconButton(
                      icon: Icon(Icons.subject),
                      onPressed: () {
                        null;
                      },
                      color: Colors.blue,
                    ),
                    IconButton(
                      alignment: Alignment.center,
                      icon: Icon(Icons.perm_identity),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Teachers()));
                        ;
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.people),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Students()));
                        ;
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.settings),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Settings_screen()));
                      },
                    ),
                  ],
                ))));
  }
}