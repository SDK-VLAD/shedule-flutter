import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:untitled/screens/dayscreens/Friday.dart';
import 'package:untitled/screens/dayscreens/Sunday.dart';
import 'package:untitled/screens/dayscreens/Thursday1subgroup.dart';
import 'package:untitled/screens/dayscreens/Wednesday1subgroup.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';
import 'package:untitled/screens/screens_bottom/teachers.dart';

import 'package:untitled/services/auth_service.dart';

import '../../constants/constants.dart';
import '../dayscreens/Monday1subgroup.dart';
import '../dayscreens/Saturday.dart';
import '../dayscreens/Tuesday1subgroup.dart';
import '../dayscreens/Tuesday2subgroup.dart';
import '../screens_bottom/studentsscreen.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  HomeState createState() => HomeState();
}

class HomeState extends State<Home> {
  //String _teacherName;
  List dayList = [];
  late String dayElement;

  @override
  void initState() {
    // TODO: implement initState

    dayList.addAll([
      'Понедельник',
      'Вторник',
      'Среда',
      'Четверг',
      'Пятница',
      'Суббота',
      'Воскресенье'
    ]);
  }

//class Home extends StatelessWidget {
  //final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: secondary,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          foregroundColor: textcolor,
          title: const Text(
            'Расписание',
            style: TextStyle(color: textcolor),
          ),
          backgroundColor: primary,
          elevation: 0.0,
          actions: <Widget>[],
        ),
        body: Center(
          
          
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
                TextButton(
            child: const Text('Понедельник', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const MondayScreen()));
            },
          ),
          TextButton(
            child: const Text('Вторник', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Tuesday1Screen()));
            },
          ),
          TextButton(
            child: const Text('Среда', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Wednesday1Screen()));
            },
          ),
          TextButton(
            child: const Text('Четверг', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Thursday1Screen()));
            },
          ),
          TextButton(
            child: const Text('Пятница', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const FridayScreen()));
            },
          ),
          TextButton(
            child: const Text('Суббота', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const SaturdayScreen()));
            },
          ),
          TextButton(
            child: const Text('Воскресенье', style: TextStyle(fontSize: 20, color: Colors.black),),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const SundayScreen()));
            },
          ),
            ]
          ),
            ),
            

        /*ListView.builder(
            itemCount: dayList.length,
            itemBuilder: (BuildContext context, int index) {
              if (dayList[index] == 'Понедельник') {
                return 

              };
              return Dismissible(
                  key: Key(dayList[index]),
                  child: Card(
                    child: ListTile(
                      title: Text(dayList[index]),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [],
                      ),
                    ),
                  ),
                  onDismissed: (direction) {
                    setState(() {
                      dayList.removeAt(index);
                    });
                  });
            })*/
        

        //shedulerow(),
        bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    IconButton(
                      icon: Icon(Icons.subject),
                      onPressed: () {
                        null;
                      },
                      color: Colors.blue,
                    ),
                    IconButton(
                      alignment: Alignment.center,
                      icon: Icon(Icons.perm_identity),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Teachers()));
                        ;
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.people),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Students()));
                        ;
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.settings),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Settings_screen()));
                      },
                    ),
                  ],
                ))));
  }
}

/* @override
  Widget shedulerow() *{
    return Row(mainAxisSize: MainAxisSize.min, children: [
      /*  Padding(
          padding: EdgeInsets.only(top: 50, left: 20),
          child: ElevatedButton(
              onPressed: null,
              child: Text(
                'Понедельник',
                style: TextStyle(color: Colors.white, fontFamily: 'Raleway'),
              ),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(textcolor),
              ))),
      Padding(
          padding: EdgeInsets.only(top: 50, left: 20),
          child: ElevatedButton(
              onPressed: null,
              child: Text(
                'Вторник',
                style: TextStyle(color: Colors.white, fontFamily: 'Raleway'),
              ),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(textcolor),
              ))),
      Padding(
          padding: EdgeInsets.only(top: 50, left: 20),
          child: ElevatedButton(
              onPressed: null,
              child: Text(
                'Среда',
                style: TextStyle(color: Colors.white, fontFamily: 'Raleway'),
              ),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(textcolor),
              ))),*/
    ]);
  }*/
