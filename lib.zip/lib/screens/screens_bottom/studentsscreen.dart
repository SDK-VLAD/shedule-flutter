import 'package:flutter/material.dart';
import 'package:untitled/screens/home/home.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';
import 'package:untitled/screens/screens_bottom/subjects.dart';
import 'package:untitled/screens/screens_bottom/teachers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:untitled/services/auth_service.dart';

import '../../constants/constants.dart';
import '../../databases/shedule_api.dart';

class Students extends StatefulWidget {
  const Students({Key? key}) : super(key: key);
  @override
  StudentsState createState() => StudentsState();
  
}

class StudentsState extends State<Students> {
  //String _teacherName;
  late Future<List<Students_list>> students;
  List studentList = [];
  late String studentElement;
  //bool _value1 = false;
  final bool _value2 = false;
  //void _value1Changed(bool value) => setState(() => _value1 = value);
  //void _value2Changed(bool value) => setState(() => _value2 = value);
  bool value = false;

@override
void initState() {
  super.initState();
  students = getStudentList();
}

  void initFirebase() async {
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp();
  }



  @override
  Widget shedulerow() {
    return Row(mainAxisSize: MainAxisSize.min, children: []);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: secondary,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          foregroundColor: textcolor,
          title: const Text(
            'Студенты',
            style: TextStyle(color: textcolor),
          ),
          backgroundColor: primary,
          elevation: 0.0,
          actions: <Widget>[],
        ),
        body: Center(
          child: FutureBuilder<List<Students_list>>(
            future: students,
            builder: (context, snapshot) {

              if (snapshot.hasData) {
                
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {

                return Column(children: <Widget>[
                 CheckboxListTile(title: Text(snapshot.data![index].name, style: (const TextStyle(fontWeight: FontWeight.w400, fontSize: 16) ), textAlign: TextAlign.center, ), 
                 value: value, 
                 onChanged: (value) { setState(() {this.value = value!;}); 
               },
    controlAffinity: ListTileControlAffinity.leading,), //Text(snapshot.data![index].name, style: (const TextStyle(fontWeight: FontWeight.w400, fontSize: 16) ), textAlign: TextAlign.center, ),
                   

                  

                  const Divider( height: 20, thickness: 3, indent: 0, endIndent: 0, color: Colors.black),],
                  
                  );
              });
              } 
              else if (snapshot.hasError) {
                return Text(snapshot.error.toString());
              } else {
            return CircularProgressIndicator();
              }
          }),
        ),
        
        
        
        /*body: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('Students').snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) return Text('Нет записей');
            return ListView.builder(
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (BuildContext context, int index) {
                  return Dismissible(
                      key: Key(snapshot.data!.docs[index].id),
                      child: Card(
                        child: ListTile(
                          title:
                              Text(snapshot.data!.docs[index].get('student')),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                onPressed: () {
                                  FirebaseFirestore.instance
                                      .collection('Students')
                                      .doc(snapshot.data!.docs[index].id)
                                      .delete();
                                },
                                icon: Icon(Icons.remove),
                              )
                            ],
                          ),
                        ),
                      ),
                      onDismissed: (direction) {
                        FirebaseFirestore.instance
                            .collection('Students')
                            .doc(snapshot.data!.docs[index].id)
                            .delete();
                      });
                });
          },
        ),*/
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.deepOrange,
          onPressed: () {
            showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text('Сохранить посещение в файле'),
                    content: TextField(
                      onChanged: (String value) {
                        studentElement = value;
                      },
                    ),
                    actions: [
                      ElevatedButton(
                          onPressed: () {
                            FirebaseFirestore.instance
                                .collection('Students')
                                .add({'student': studentElement});
                          },
                          child: Text('Сохранить'))
                    ],
                  );
                });
          },
          child: const Icon(Icons.text_fields),
        ),
        bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    IconButton(
                      icon: Icon(Icons.subject),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Home()));
                        ;
                      },
                    ),
                    IconButton(
                      alignment: Alignment.center,
                      icon: Icon(Icons.perm_identity),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Teachers()));
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.people),
                      onPressed: () {
                        null;
                        ;
                      },
                      color: Colors.blue,
                    ),
                    IconButton(
                      icon: Icon(Icons.settings),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Settings_screen()));
                      },
                    ),
                    
                  ],
                ))));
  }
}
