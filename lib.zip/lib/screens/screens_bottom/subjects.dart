import 'package:firebase_database/firebase_database.dart';

import 'package:flutter/material.dart';

import '../home/home.dart';
import 'settings_screen.dart';
import 'teachers.dart';





class Subjects extends StatefulWidget {
  const Subjects({ Key? key }) : super(key: key);

  @override
  State<Subjects> createState() => _SubjectsState();
  
}
FirebaseDatabase database = FirebaseDatabase.instance;
final usersQuery = FirebaseDatabase.instance.ref();
late DatabaseReference databaseReference;
String databasejson = '';

var discipline;
var classroom;
var lesson_order;
var time;
var weekday;
var teacher;
var week;
var subgroup;


_readdb_onechild() {
  databaseReference
              .child("Предмет")
              .child("Кабинет")
              .child("Время")
              .child("День недели")
              .child("Преподаватель")
              .child("Неделя")
              .child("Подгруппа")
              .once()
              .then((event) {
                final dataSnapshot = event.snapshot;
                
                print("read once - " + dataSnapshot.value.toString());
                (() {
                  databasejson = dataSnapshot.value.toString();
                }
                );
              });
}


class _SubjectsState extends State<Subjects> {
  @override
  Widget build(BuildContext context) {
    
final dbRef = FirebaseDatabase.instance.ref().child("timetable");
Stream<DatabaseEvent> stream = dbRef.onValue;//new
     return 
     Scaffold(
       appBar: AppBar(title: Text("Расписание"),), 
       
       body: Center(heightFactor: 100, 
       
       
       child: FutureBuilder<dynamic>(
      future: dbRef.once(),
      
      builder: (ctx, AsyncSnapshot snapshot){
        if(snapshot.connectionState == ConnectionState.waiting){
                return const Center(child: CircularProgressIndicator());
              }
        if(snapshot.hasData){
final timetable = snapshot.data!.snapshot;
          
          
          return ListView.builder(
            shrinkWrap: true,
            itemCount: 5,
            itemBuilder: (BuildContext context, i)=> Container(
              height: 100,
              width: 100,
              
              child:  Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Column(

                  children: [
  Text(timetable.children.toList()[i].child('discipline').value),
  Text(timetable.children.toList()[i].child('classroom').value),
  Text(timetable.children.toList()[i].child('teacher').value),
],
                ), 
                
              ),
              
              
            ),
            );
        }
        return const Center(child: Text('Нет доступа к БД'),);

        
      },
      ),
      ),
      bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    IconButton(
                      icon: Icon(Icons.subject),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Home()));
                        ;
                      },
                    ),
                    IconButton(
                      alignment: Alignment.center,
                      icon: Icon(Icons.perm_identity),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Teachers()));
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.people),
                      onPressed: () {
                        null;
                        ;
                      },
                      
                    ),
                    IconButton(
                      icon: Icon(Icons.settings),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Settings_screen()));
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.abc),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Subjects()));
                      },
                      color: Colors.blue,
                    ),
                  ],
                )))
     );
     
}
    
}
         

