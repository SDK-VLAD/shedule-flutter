import 'package:flutter/material.dart';
import 'package:untitled/constants/constants.dart';
import 'package:untitled/screens/authenticate/authenticate.dart';
import 'package:untitled/screens/home/home.dart';
import 'package:untitled/screens/screens_bottom/studentsscreen.dart';
import 'package:untitled/screens/screens_bottom/teachers.dart';
import 'package:untitled/services/auth_service.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

//class Settings extends StatelessWidget {
class Settings_screen extends StatefulWidget {
  const Settings_screen({Key? key}) : super(key: key);
  @override
  Settings_screenState createState() => Settings_screenState();
}

void _signOut() {
  FirebaseAuth.instance.signOut();

  User? user = FirebaseAuth.instance.currentUser;
  //print('$user');
  runApp(new MaterialApp(
    home: new Authenticate(),
  ));
}

class Settings_screenState extends State<Settings_screen> {
  final AuthService _authService = AuthService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(
            'Настройки',
            style: TextStyle(color: textcolor),
          ),
          backgroundColor: primary,
          foregroundColor: textcolor,
          elevation: 0.0,
          actions: <Widget>[
            TextButton.icon(
              icon: Icon(Icons.person),
              style: TextButton.styleFrom(
                primary: textcolor,
              ),
              label: const Text(
                'Выйти',
                style: TextStyle(color: textcolor),
              ),
              onPressed: () {
                _signOut(); //async {
                //await _authService.signOut();
              },
            )
          ],
        ),
        body: Container(
            padding: EdgeInsets.only(top: 10),
            child: Column(
              children: const [
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Text(
                    'Id Пользователя:',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Text(
                    'email@email.com',
                    style: TextStyle(fontSize: 25),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Text('ФИО:'),

                ),
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: TextField(),

                ),
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Text(
                    'Группа: ',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: TextField(),

                ),
              ],
            )),
        bottomNavigationBar: Container(
            height: 60,
            child: Padding(
                padding: EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    IconButton(
                      icon: const Icon(Icons.subject),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Home()));
                      },
                    ),
                    IconButton(
                      alignment: Alignment.center,
                      icon: new Icon(Icons.perm_identity),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Teachers()));
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.people),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Students()));
                        ;
                      },
                    ),
                    IconButton(
                      icon: new Icon(Icons.settings),
                      onPressed: () {
                        null;
                      },
                      color: Colors.blue,
                    ),
                  ],
                ))));
  }
}
