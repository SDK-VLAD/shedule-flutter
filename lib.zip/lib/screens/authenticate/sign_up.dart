import 'package:flutter/material.dart';

import 'package:untitled/constants/constants.dart';
import 'package:untitled/services/auth_service.dart';

class SignUp extends StatefulWidget {
  final Function toggelView;
  SignUp({required this.toggelView});
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final AuthService _authService = AuthService();
  final _formKey = GlobalKey<FormState>();
  bool loading = false;

  // text field state
  String email = '';
  String password = '';
  String error = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: primary,
        foregroundColor: textcolor,
        elevation: 0.0,
        title: Text('Расписание'),
        actions: <Widget>[
          TextButton.icon(
            onPressed: () {
              widget.toggelView();
            },
            style: TextButton.styleFrom(
              primary: secondary,
            ),
            icon: Icon(
              Icons.person,
              color: Colors.black,
            ),
            label: Text(
              'Войти',
              style: TextStyle(color: Colors.black),
            ),
          )
        ],
      ),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 50.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              SizedBox(height: 20.0),
              TextFormField(
                validator: (value) => value!.isEmpty ? ('Введите email') : null,
                onChanged: (value) {
                  setState(() => email = value);
                },
              ),
              SizedBox(height: 20.0),
              TextFormField(
                validator: (value) => value!.length < 6
                    ? 'Пароль должен быть больше 6 символов'
                    : null,
                obscureText: true,
                onChanged: (value) {
                  setState(() => password = value);
                },
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                  child: Text(
                    'Зарегистрироваться',
                    style: TextStyle(color: secondary),
                  ),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      setState(() => loading = true);
                      dynamic result =
                          await _authService.signUp(email, password);
                      if (result == null) {
                        setState(() {
                          error = 'Введите корректный email/Пароль';
                          loading = false;
                        });
                      }
                    }
                  }),
              SizedBox(height: 12.0),
              Text(
                error,
                style: TextStyle(color: errorColor, fontSize: 14.0),
              )
            ],
          ),
        ),
      ),
    );
  }
}
