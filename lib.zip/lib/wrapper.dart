import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:untitled/models/userModel.dart';
import 'package:untitled/screens/authenticate/authenticate.dart';
import 'package:untitled/screens/home/home.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';

class Wrapper extends StatelessWidget {
  const Wrapper({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final userModel = Provider.of<UserModel?>(context);
    if (userModel == null) {
      return Authenticate();
    } else {
      return new Settings_screen();
    }
  }
}
