import 'package:flutter/material.dart';

const primary = Color(0xffE5E5E5);
const primarysign = Colors.blueAccent;
const textcolor = Color(0xff000000);
const secondary = Color.fromRGBO(247, 250, 252, 1.0);
const secondarysign = Colors.black;
const header = Color.fromRGBO(82, 95, 127, 1.0);
const errorColor = Color.fromRGBO(245, 54, 92, 1.0);
const buttonColor = Color(0xff000000);

const defaultPadding = 16.0;
