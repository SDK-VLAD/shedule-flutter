import 'dart:convert';
import 'package:http/http.dart' as http;
class Timetables {
  String id;
  String discipline;
  String lessonOrder;
  String week;
  String subgroup;
  String teacher;
  String weekday;
  String classroom;
  // ignore: constant_identifier_names
  static const String dayCheck1 = '1';
  static const String dayCheck2 = '2'; 
  static const String dayCheck3 = '3'; 
  static const String dayCheck4 = '4'; 
  static const String dayCheck5 = '5'; 
  static const String dayCheck6 = '6'; 
  static const String dayCheck7 = '7';   

  Timetables({
    required this.id,
    required this.discipline,
    required this.lessonOrder,
    required this.week,
    required this.subgroup,
    required this.teacher,
    required this.weekday,
    required this.classroom
  });

  factory Timetables.fromJson(Map<String, dynamic> json) => Timetables(
    id: json['id'], 
    discipline: json ['discipline'],
    lessonOrder: json ['lesson_order'],
    week: json ['week'],
    subgroup: json ['subgroup'],
    teacher: json ['teacher'],
    weekday: json ['weekday'],
    classroom: json ['classroom']
    );
}

class Students_list {
  String id;
  String name;
  String group_id;

  Students_list({
    required this.id,
    required this.name,
    required this.group_id,
  });

  factory Students_list.fromJson(Map<String, dynamic> json) => Students_list(
    id: json['id'], 
    name: json ['name'],
    group_id: json ['group_id'],
    );
}




Future<List<Timetables>> getTimetablesMonday1() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/30cd17a5afaa906e1456fcd158d7c235/raw/12e01b463617c2f9d53a62fb7fa1a709acba3350/Monday_timetable_1.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Timetables> timetables = [];
    for (var u in jsonResponce) {
      Timetables timetable = 
      Timetables(id: u['id'], 
      classroom: u['classroom'],
      discipline: u['discipline'], 
      lessonOrder: u['lesson_order'], 
      subgroup: u['subgroup'], 
      teacher: u['teacher'], 
      weekday: u['weekday'],
      week: u['week']);
      timetables.add(timetable);
    }
    return timetables;
  } else {
    throw Exception('Ошибка');
  }
}

Future<List<Timetables>> getTimetablesMonday2() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/3d90cd7e95becaaa247edd22737d2231/raw/a869960b636f2f9075ef1d5c3b442bf9a428d2d8/Monday_timetable_2.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Timetables> timetables = [];
    for (var u in jsonResponce) {
      Timetables timetable = 
      Timetables(id: u['id'], 
      classroom: u['classroom'],
      discipline: u['discipline'], 
      lessonOrder: u['lesson_order'], 
      subgroup: u['subgroup'], 
      teacher: u['teacher'], 
      weekday: u['weekday'],
      week: u['week']);
      timetables.add(timetable);
    }
    return timetables;
  } else {
    throw Exception('Ошибка');
  }
}

Future<List<Timetables>> getTimetablesTuesdays1() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/f778a7ba6a2cb9a3ba566962216e3c09/raw/c42416f2e85957f69d33bc5cfa1f866be9b87220/Tuesday_timetable1.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Timetables> timetables = [];
    for (var u in jsonResponce) {
      Timetables timetable = 
      Timetables(id: u['id'], 
      classroom: u['classroom'],
      discipline: u['discipline'], 
      lessonOrder: u['lesson_order'], 
      subgroup: u['subgroup'], 
      teacher: u['teacher'], 
      weekday: u['weekday'],
      week: u['week']);
      timetables.add(timetable);
    }
    return timetables;
  } else {
    throw Exception('Ошибка');
  }
}

Future<List<Timetables>> getTimetablesWednesday1() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/2447aca72526fa190bd9d09c64c48b64/raw/71eb73bebdf6e51ddf4f0f300957efb9fb33712f/Wednesday_timetable_1.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Timetables> timetables = [];
    for (var u in jsonResponce) {
      Timetables timetable = 
      Timetables(id: u['id'], 
      classroom: u['classroom'],
      discipline: u['discipline'], 
      lessonOrder: u['lesson_order'], 
      subgroup: u['subgroup'], 
      teacher: u['teacher'], 
      weekday: u['weekday'],
      week: u['week']);
      timetables.add(timetable);
    }
    return timetables;
  } else {
    throw Exception('Ошибка');
  }
}

Future<List<Timetables>> getTimetablesThursday1() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/1cdd204f2e2a0baa5ff32147005e3e19/raw/4647e4b9fa3062d9011aee5f8c338f69612f4bec/Thursday_timetable_1.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Timetables> timetables = [];
    for (var u in jsonResponce) {
      Timetables timetable = 
      Timetables(id: u['id'], 
      classroom: u['classroom'],
      discipline: u['discipline'], 
      lessonOrder: u['lesson_order'], 
      subgroup: u['subgroup'], 
      teacher: u['teacher'], 
      weekday: u['weekday'],
      week: u['week']);
      timetables.add(timetable);
    }
    return timetables;
  } else {
    throw Exception('Ошибка');
  }
}

Future<List<Timetables>> getTeacherList() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/f415b43b48cc3c6d7990931e618dd8ef/raw/336cdfd53bebc27f930bd001cbce2fab6fb43a0e/Teachers.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Timetables> timetables = [];
    for (var u in jsonResponce) {
      Timetables timetable = 
      Timetables(id: u['id'], 
      classroom: u['classroom'],
      discipline: u['discipline'], 
      lessonOrder: u['lesson_order'], 
      subgroup: u['subgroup'], 
      teacher: u['teacher'], 
      weekday: u['weekday'],
      week: u['week']);
      timetables.add(timetable);
    }
    return timetables;
  } else {
    throw Exception('Ошибка');
  }

  
}

Future<List<Students_list>> getStudentList() async {
  final responce = await http.get(
    Uri.parse('https://gist.githubusercontent.com/SDK-VLAD/cd9c7adcf1c337a6fe38e17530c85028/raw/b6264841f2ad87c77dd011cfe1b662a70791d33d/Students.json'),

  );
  if (responce.statusCode == 200) {
    var jsonResponce = json.decode(responce.body);
    List<Students_list> student = [];
    for (var u in jsonResponce) {
      Students_list students = Students_list(
      id: u['id'], 
      name: u['name'], 
      group_id: u['group_id']);
      student.add(students);
    }
    return student;
  } else {
    throw Exception('Ошибка');
  }
}