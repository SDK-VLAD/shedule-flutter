import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:untitled/models/userModel.dart';
import 'package:untitled/screens/screens_bottom/settings_screen.dart';
import 'package:untitled/services/auth_service.dart';
import 'package:untitled/wrapper.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FirebaseApp firebaseApp = await Firebase.initializeApp();
  ThemeData();
  await Firebase.initializeApp(
    // Replace with actual values
    options: DefaultFirebaseOptions.currentPlatform,
    
  );
  runApp(MyApp());
}



class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return StreamProvider<UserModel?>.value(
        initialData: null,
        value: AuthService().onAuthStateChanged,
        builder: (context, snapshot) {
          return MaterialApp(
            initialRoute: '/',
            routes: {
              '/': (context) => Wrapper(),
              'shedule': (context) => Settings_screen(),
            },
            //home: Wrapper(),
          );
        });
  }
}
